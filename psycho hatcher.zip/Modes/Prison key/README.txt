▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
PRISON KEYS - AutoHotKey 2.0 Macro for Pet Simulator 99
----------------------------------------------------------------------------------------
Copyright © waktool
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰


▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
FUNCTIONALITY
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

This macro uses prison keys to open the cells in the Prison Block.

Macro features:
• Unlocks cells and opens chests.
• Error handling for latency issues.
• Auto-Reconnects.


▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
REQUIREMENTS
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

AutoHotKey
----------------------------------------------------------------------------------------
1. Get AutoHotKey 2.0 from https://www.autohotkey.com/ and install it.

Macro
----------------------------------------------------------------------------------------
1. Download the macro's zip file.
2. Unzip the downloaded file.
3. Remove the zip file after extraction.

Computer
----------------------------------------------------------------------------------------
1. Display Resolution must be 1920x1080 (Windows Key + I, Home, Display).
2. Scale must be 100% (Windows Key + I, Home, Display).
3. Windows Taskbar "Automatically hide the taskbar" must be disabled (Windows Key + I, Personalization, Taskbar).
4. Make sure you are using a QWERTY keyboard layout.

Roblox
----------------------------------------------------------------------------------------
1. Client must be the Roblox Web version (https://www.roblox.com/), not the Microsoft Store version.
2. Set Camera Mode to Classic (Escape Key, Settings).
3. Set Movement Mode to Default (Keyboard) (Escape Key, Settings).
4. Set Action Mode to Priority (Settings icon, Action Menu).
5. Set Vibrations to Off (Settings icon, Action Menu) - prevents Massive Comet drops from disrupting the camera.

Pet Sim 99 Requirements
-----------------------------------------------------------------------------------------------
1. Ensure Zone 204 is unlocked.
2. Standard Hoverboard (shiny hoverboards will disrupt the pathing).
2. Recommended: 60+ FPS.


▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
USING THE MACRO
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

Set Up the Macro
----------------------------------------------------------------------------------------
1. Navigate to the folder where you extracted the zip file.
2. Open the Settings sub-folder.
3. Open the Settings.ini file in Notepad.
4. Update the Settings.ini file with your preferences.

Load the Macro
-----------------------------------------------------------------------------------------------
1. Navigate to the folder where you extracted the zip file.
2. Double-click the AHK file. This will initiate the macro and automatically open the graphical user interface (GUI).

First-time Use
-----------------------------------------------------------------------------------------------
1. Launch PS99.
2. Start the macro (this will alter your fonts, which will only take effect after restarting Roblox).
3. Close the Roblox client.
4. Restart Roblox/PS99.
5. Restart the macro.
Note: Your font will retain the new fonts until you click the "Default Font" button and restart Roblox.

Regular Use
-----------------------------------------------------------------------------------------------
1. Launch PS99.
2. Navigate to World 3.
3. Activate the macro.
Note: Avoid adjusting the camera!
Note: Do not turn off your screen!

Hot Keys
----------------------------------------------------------------------------------------
• F5 to exit the macro.
• F8 to pause and unpause the macro.
Note: These shortcuts are configurable in settings.

Interface (GUI)
----------------------------------------------------------------------------------------
• Zone (ListView Column): The current zone.
• Action (ListView Column): The current action that is being performed.
• Pause (Button): Pauses or unpauses the macro.
• Help (Button): Opens this file in Notepad.
• Reconnect (Button): Reconnects.

User Configuration (Basic)
----------------------------------------------------------------------------------------
• Review the "Settings\Settings.ini" file and adjust it to match your game settings and preferences.

User Configuration (Advanced)
----------------------------------------------------------------------------------------
• Review the "Lib\Coords.ahk" file to adjust coordinate locations for PS99 controls.
• Review the "Lib\Movement.ahk" file to change movement to different areas (e.g., best egg).
• Review the "Lib\Delays.ahk" file to modify delay times between different in-game actions (e.g., after closing the Inventory menu).


▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
FEEDBACK & SUPPORT
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

Feedback and Support
----------------------------------------------------------------------------------------
Join us in the NONG Discord server to provide feedback or get support:
https://discord.com/invite/nong

Say Thanks
----------------------------------------------------------------------------------------
If the macro helped you and you would like to say thanks, send gems or items in game to:
waktool


▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
KNOWN ISSUES
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

• Pathing Issues Due to Latency and Low FPS: The route to the cell doors may be disrupted
    by latency or low frame rates. However, corrective measures are implemented to
    address such disruptions, such as verifying unlocked rooms for any chests that remain
    unopened.


▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
Change Log
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰

0.3.1
----------------------------------------------------------------------------------------
• Fixed an issue where the macro was unable to locate the Search Box flashing cursor due to it being shifted by 6 pixels.

0.3
----------------------------------------------------------------------------------------
• Introduced a new setting, KeyPreference, allowing users to choose their preferred key for unlocking cells.
• Added a new setting ShortStature for avatars that are lacking in height (i.e., do not bounce off the front of the bunkbeds but instead move inside them and bang against the wall).
• Enhanced the GUI to display the current count of keys.
• Consolidated all cell path configurations into Movement.ahk, enabling easy customisation based on user preferences.
• Bug Fix: Resolved "Error: Can not use language "en" for OCR, please reinstall language pack."
• Bug Fix: Resolved "Error: This value of type "OCR" has no property named "ptr"."


0.2
----------------------------------------------------------------------------------------
• Auto-Reconnect check updated to trigger after each cell, instead of after processing all 8 cells.
• Added Ultimate skill use to the end of the 8 cell cycle (thanks to Devil for the suggestion).
• Minor adjustments to paths.

0.1
----------------------------------------------------------------------------------------
Initial version.
<picture>
  <img src="https://raw.githubusercontent.com/waktool/.github/main/assets/PS99_Fuse_Machine.webp">
</picture>

<a name="title"><h1># Fuse Pets</h1></a>
A macro that fuses pets using the Supercomputer.
- <a href="https://github.com/waktool/FusePets/releases">Releases</a>
- <a href="https://github.com/waktool/FusePets/wiki">Wiki</a>
- <a href="https://github.com/waktool/FusePets/issues">Issues & Suggestions</a>
